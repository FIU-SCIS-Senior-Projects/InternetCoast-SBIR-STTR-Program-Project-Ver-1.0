﻿namespace InternetCoast.Infrastructure.Data.EF.Context
{
    public class UiContext
    {
        public string ApplicationIdentifier { get; set; }
        public int UserId { get; set; }
    }
}
